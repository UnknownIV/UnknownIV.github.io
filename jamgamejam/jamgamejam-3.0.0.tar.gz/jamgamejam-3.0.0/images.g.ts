// Auto-generated code. Do not edit.
namespace myImages {

    helpers._registerFactory("image", function(name: string) {
        switch(helpers.stringTrim(name)) {
            case "y=4h/n}=%mAv9mFDi[kG":
            case "Aristide_down":return img`
. . . . f b b b b b f . . . . . 
. . . f b f f f f f b f . . . . 
. . f b f f f f f f f b f . . . 
. f b f f f f f f f f f b f . . 
. f b f 1 1 f f f 1 1 f b f . . 
. f b f 1 1 f f f 1 1 f b f . . 
. f b f 1 1 f f f 1 1 f b f . . 
. f b f f f f f f f f f b f . . 
. . f b f f f f f f f f b f . . 
. . . f b b f f f f b b f . . . 
. . f c c c c a d c c c c f . . 
. . f d d c c d a c c d d f . . 
. . f d c c b b b b c c d f . . 
. . f c c b b b b b b c c f . . 
. . . f b f f f f f f b f . . . 
. . . . . f f . . f f . . . . . 
`;
            case "image2":
            case "Aristide_up":return img`
. . . . . f b c c b b f . . . . 
. . . . f b b c c b b a f . . . 
. . . f b a c a a c a b b f . . 
. . f b b c a f 2 a c b b b f . 
. . f c c c a f f a c c c c f . 
. . f c c c a f f a c c c c f . 
. . f b b c a f f a c b b b f . 
. . f b b a c a a c a b b b f . 
. . f a a b b c c b b a a f . . 
. . . f c c c c c c c c f . . . 
. . f c a b a c c a b a c f . . 
. . f c b a b c c b a b c f . . 
. . f c b b a c c a b b c f . . 
. . f c b a b c c b a b c f . . 
. . . f c f f f f f f c f . . . 
. . . . . f f . . f f . . . . . 
`;
            case "image3":
            case "Aristide_left":return img`
. . . . . f b b b b b f . . . . 
. . . . f b f f f f f b f . . . 
. . . f b f f f f f f f b f . . 
. . f b f f f f f f f f f b f . 
. . f b 1 1 f f f 1 1 f f b f . 
. . f b 1 1 f f f 1 1 f f b f . 
. . f b 1 1 f f f 1 1 f f b f . 
. . f b f f f f f f f f f b f . 
. . f b f f f f f f f f b f . . 
. . . f b b f f f f b b f . . . 
. . f c c c c d d c c c c f . . 
. . f d d c c a a c c d d f . . 
. . f d c c b b b b c c d f . . 
. . f c c b b b b b b c c f . . 
. . . f b f f f f f f b f . . . 
. . . . . f f . . f f . . . . . 
`;
            case "image4":
            case "Aristide_Right":return img`
. . . . f b b b b b f . . . . . 
. . . f b f f f f f b f . . . . 
. . f b f f f f f f f b f . . . 
. f b f f f f f f f f f b f . . 
. f b f f 1 1 f f f 1 1 b f . . 
. f b f f 1 1 f f f 1 1 b f . . 
. f b f f 1 1 f f f 1 1 b f . . 
. f b f f f f f f f f f b f . . 
. . f b f f f f f f f f b f . . 
. . . f b b f f f f b b f . . . 
. . f c c c c a a c c c c f . . 
. . f d d c c d d c c d d f . . 
. . f d c c b b b b c c d f . . 
. . f c c b b b b b b c c f . . 
. . . f b f f f f f f b f . . . 
. . . . . f f . . f f . . . . . 
`;
            case "image1":
            case "Aristide_up_Left":return img`
. . . . . f c c b b a f . . . . 
. . . . f b c c b b a b f . . . 
. . . f b c a a c a b b b f . . 
. . f b c a f 2 a c b b b b f . 
. . f c c a f f a c c c c c f . 
. . f c c a f f a c c c c c f . 
. . f b c a f f a c b b b b f . 
. . f b a c a a c a b b b b f . 
. . f a a b b c c b a a a f . . 
. . . f c c c c c c c c f . . . 
. . f c a b a c c a b a c f . . 
. . f c b a b c c b a b c f . . 
. . f c b b a c c a b b c f . . 
. . f c b a b c c b a b c f . . 
. . . f c f f f f f f c f . . . 
. . . . . f f . . f f . . . . . 
`;
            case "image5":
            case "Aristide_up_Right":return img`
. . . . f a b b c c f . . . . . 
. . . f b a b b c c b f . . . . 
. . f b b b a c a a c b f . . . 
. f b b b b c a f 2 a c b f . . 
. f c c c c c a f f a c c f . . 
. f c c c c c a f f a c c f . . 
. f b b b b c a f f a c b f . . 
. f b b b b a c a a c a b f . . 
. . f a a a b c c b b a a f . . 
. . . f c c c c c c c c f . . . 
. . f c a b a c c a b a c f . . 
. . f c b a b c c b a b c f . . 
. . f c b b a c c a b b c f . . 
. . f c b a b c c b a b c f . . 
. . . f c f f f f f f c f . . . 
. . . . . f f . . f f . . . . . 
`;
            case "image7":
            case "BasicSword":return img`
f f f f . . . . . . . . . . . . 
f d 1 1 f . . . . . . . . . . . 
f 1 d 1 1 f . . . . . . . . . . 
f 1 1 d 1 1 f . . . . . . . . . 
. f 1 1 d 1 1 f . . . . . . . . 
. . f 1 1 d 1 1 f . . . . . . . 
. . . f 1 1 d 1 1 f . . . . . . 
. . . . f 1 1 d 1 1 f . . . . . 
. . . . . f 1 1 d 1 1 f f . . . 
. . . . . . f 1 1 d 1 e e f . . 
. . . . . . . f 1 1 a b e f . . 
. . . . . . . . f e b a e f . . 
. . . . . . . . f e e e e e f . 
. . . . . . . . . f f f e e e f 
. . . . . . . . . . . . f e e f 
. . . . . . . . . . . . . f f f 
`;
            case "H5}94QSC+hI?L0+R_Kq5":
            case "hammer":return img`
f f f . f f f d d f . . . . . . 
f a b f f f d 1 1 d f . . . . . 
f b a d d d d 1 1 1 d f . . . . 
. f d 1 1 1 d d 1 1 1 d f . . . 
f f d 1 1 1 1 d d 1 1 1 d f . . 
f f d 1 1 1 1 1 d d 1 d d f . . 
f d d d 1 1 1 1 1 d d f f f . . 
d 1 1 d d 1 1 1 1 d f . . f . . 
d 1 1 1 d d 1 1 1 f f . . . . . 
f d 1 1 1 d d d f e e f . . . . 
. f d 1 1 d f f f e e e f . . . 
. . f d d f . . . f e e e f . . 
. . . f d f . . . . f e e e f . 
. . . . f f f . . . . f e e e f 
. . . . . . . . . . . . f e e e 
. . . . . . . . . . . . . f e e 
`;
            case "image6":
            case "boneAndfireSword":return img`
f f f f . . . . . . . . . . . . 
f 4 2 2 f . . . . . . . . . . . 
f 2 4 2 2 f . . . . . . . . . . 
f 2 2 4 2 2 f . . . . . . . . . 
. f 2 2 4 2 2 f . . . . . . . . 
. . f 2 2 4 2 2 f . . . . . . . 
. . . f 2 2 4 2 2 f . . . . . . 
. . . . f 2 2 4 2 2 f . . . . . 
. . . . . f 2 2 4 2 2 f f . . . 
. . . . . . f 2 2 4 2 2 1 f . . 
. . . . . . . f 2 2 4 2 1 f . . 
. . . . . . . . f 2 2 4 1 f . . 
. . . . . . . . f 1 1 1 1 d f . 
. . . . . . . . . f f f d 1 d f 
. . . . . . . . . . . . f d 1 f 
. . . . . . . . . . . . . f f f 
`;
            case "IeENGL;#ds?0^[G0fXvE":
            case "Monkey":return img`
. . . . f f f f f . . . . . . . 
. . . f e e e e c f . . . . . . 
. . f d d d d e e c f . . . . . 
. c d f d d f d e c f f . . . . 
. c d f d d f d e c d d f . . . 
c d e e d d d d e c b d c . . . 
c d d d d c d d e c b d c . . . 
c c c c c d d e e c f c . . . . 
. f d d d d e e e f f . . . . . 
. . f f f f f e e e c f . . . . 
. . . . f f e e e e e c f . f f 
. . . f e e f e e f e e f . c f 
. . f e e f e e f e e e f . c f 
. f b d f d b f b b f e f f c f 
. f d d f d d f d d b c f f f f 
. . f f f f f f f f f f f f f . 
`;
            case "image8":
            case "myImage":return img`
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . c c . . . . . . . . . . 
. . . c b b c c . . . . . . . . 
. . c b b b a a c c . . . . . . 
. c b b b b b b a a c c . . . . 
c b b b b b b b b b a a c . . . 
. c b b b b b b a a c c . . . . 
. . c c b b a a c c . . . . . . 
. . . . c a c c . . . . . . . . 
. . . . . c . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
. . . . . . . . . . . . . . . . 
`;
        }
        return null;
    })

    helpers._registerFactory("animation", function(name: string) {
        switch(helpers.stringTrim(name)) {

        }
        return null;
    })

    helpers._registerFactory("song", function(name: string) {
        switch(helpers.stringTrim(name)) {
            case "song1":
            case "BG1":return hex`00c8000408040300001c00010a006400f401640000040000000000000000000000000005000004900004000800011d0c001000011d14001800011e18001c00011b1c002000012220002400012024002800011b2c003000011d30003400011d34003800011b38003c00011e40004400011944004800011d4c005000011b50005400011954005800012758005c0001255c006000011d60006400011b68006c0001226c007000012074007800012078007c0001227c008000011b06001c00010a006400f401640000040000000000000000000000000000000002b40000000400011b08000c00011910001400011d14001800011d18001c0001201c002000012020002400011d24002800011e28002c00011d2c003000011e30003400011d34003800011e38003c00011d3c004000011b40004400011d44004800011b48004c00011d4c005000011b50005400012754005800012458005c0001205c006000012460006400012064006800011d68006c0001206c007000011d70007400011974007800011d78007c0001277c008000012009010e02026400000403780000040a000301000000640001c80000040100000000640001640000040100000000fa0004af00000401c80000040a00019600000414000501006400140005010000002c0104dc00000401fa0000040a0001c8000004140005d0076400140005d0070000c800029001f40105c201f4010a0005900114001400039001000005c201f4010500058403050032000584030000fa00049001000005c201f4010500058403c80032000584030500640005840300009001049001000005c201f4010500058403c80064000584030500c8000584030000f40105ac0d000404a00f00000a0004ac0d2003010004a00f0000280004ac0d9001010004a00f0000280002d00700040408070f0064000408070000c80003c800c8000e7d00c80019000e64000f0032000e78000000fa00032c01c8000ee100c80019000ec8000f0032000edc000000fa0003f401c8000ea901c80019000e90010f0032000ea4010000fa0001c8000004014b000000c800012c01000401c8000000c8000190010004012c010000c80002c800000404c8000f0064000496000000c80002c2010004045e010f006400042c010000640002c409000404c4096400960004f6090000f40102b80b000404b80b64002c0104f40b0000f401022003000004200300040a000420030000ea01029001000004900100040a000490010000900102d007000410d0076400960010d0070000c80060000400050001000c000d0001001400150001001c001d0001002400250001002c002d0001003400350001003c003d0001004400450001004c004d0001005400550001005c005d0001006400650001006c006d0001007400750001007c007d000100`;
            case "song2":
            case "BG0":return hex`005a000408060206001c00010a006400f401640000040000000000000000000000000000000002030100000400011d04000800011d08000c0001190c001000011d10001400011214001800011b18001c00010f1c002000011d2000240002141924002800011d28002c00020c192c003000021b1e30003400011934003800011b38003c00030d191d3c004000011240004400011948004c00011d4c005000011450005400011b54005800010f58005c00011e5c006000021b1e60006400030d161968006c0002121d70007400020f1974007800010f78007c00020c1b7c00800002081d84008800011b8c009000011e94009800021b209c00a000010fa000a400011da400a800011da800ac000119ac00b000011bb000b4000119b400b800011eb800bc00011dbc00c000011d09010e02026400000403780000040a000301000000640001c80000040100000000640001640000040100000000fa0004af00000401c80000040a00019600000414000501006400140005010000002c0104dc00000401fa0000040a0001c8000004140005d0076400140005d0070000c800029001f40105c201f4010a0005900114001400039001000005c201f4010500058403050032000584030000fa00049001000005c201f4010500058403c80032000584030500640005840300009001049001000005c201f4010500058403c80064000584030500c8000584030000f40105ac0d000404a00f00000a0004ac0d2003010004a00f0000280004ac0d9001010004a00f0000280002d00700040408070f0064000408070000c80003c800c8000e7d00c80019000e64000f0032000e78000000fa00032c01c8000ee100c80019000ec8000f0032000edc000000fa0003f401c8000ea901c80019000e90010f0032000ea4010000fa0001c8000004014b000000c800012c01000401c8000000c8000190010004012c010000c80002c800000404c8000f0064000496000000c80002c2010004045e010f006400042c010000640002c409000404c4096400960004f6090000f40102b80b000404b80b64002c0104f40b0000f401022003000004200300040a000420030000ea01029001000004900100040a000490010000900102d007000410d0076400960010d0070000c80096000400050001000c000d0001001400150001001c001d0001002400250001002c002d0001003400350001003c003d0001004400450001004c004d0001005400550001005c005d0001006400650001006c006d0001007400750001007c007d0001008000810001078400850001008c008d0001009400950001009c009d000100a400a5000100ac00ad000100b400b5000100bc00bd000100`;
        }
        return null;
    })

}
// Auto-generated code. Do not edit.
